{
  "name": "MSSQL",
  "server": "localhost",
  "driver": "MSSQL",
  "port": 1433,
  "database": "test_db",
  "username": "sa",
  "askForPassword": false,
  "password": "root(!)Password",
  "connectionTimeout": 15,
}